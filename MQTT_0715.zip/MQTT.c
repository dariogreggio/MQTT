/*********************************************************************
 *
 *	MQTT Internet Of Things (MQTT) Client
 *	Module for Microchip TCP/IP Stack
 *   -Transceive MQQT Client datagrams
 *	 -Reference: MQTT V3.1.1
 *
 *********************************************************************
 * FileName:        MQTT.c
 * Dependencies:    TCP, ARP, DNS, Tick
 * Processor:       PIC18, PIC24F, PIC24H, dsPIC30F, dsPIC33F, PIC32
 * Compiler:        Microchip C32 v1.05 or higher
 *					Microchip C30 v3.12 or higher
 *					Microchip C18 v3.30 or higher
 *					HI-TECH PICC-18 PRO 9.63PL2 or higher
 * Company:         Microchip Technology, Inc.
 *
 * Software License Agreement
 *
 * Copyright (C) 2002-2009 Microchip Technology Inc.  All rights reserved.
 * Copyright (C) 2013,2014 Cyberdyne.  All rights reserved.
 *
 * Microchip licenses to you the right to use, modify, copy, and
 * distribute:
 * (i)  the Software when embedded on a Microchip microcontroller or
 *      digital signal controller product ("Device") which is
 *      integrated into Licensee's product; or
 * (ii) ONLY the Software driver source files ENC28J60.c, ENC28J60.h,
 *		ENCX24J600.c and ENCX24J600.h ported to a non-Microchip device
 *		used in conjunction with a Microchip ethernet controller for
 *		the sole purpose of interfacing with the ethernet controller.
 *
 * You should refer to the license agreement accompanying this
 * Software for additional information regarding your rights and
 * obligations.
 *  http://docs.oasis-open.org/mqtt/mqtt/v3.1.1/os/mqtt-v3.1.1-os.pdf
 *	https://developer.ibm.com/iot/recipes/improvise/
 *	https://internetofthings.ibmcloud.com/dashboard/#/organizations/mkxk7/devices
 *	https://developer.ibm.com/iot/recipes/improvise-registered-devices/
 * 
 * Author               Date    Comment
 *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 * Howard Schlunder     3/03/06	Original
 * Howard Schlunder			11/2/06	Vastly improved for release
 * Dario Greggio				30/9/14	client MQTT (IoT), inizio
 * - A simple client for MQTT.  Original Code - Nicholas O'Leary  http://knolleary.net
 * - Adapted for Spark Core by Chris Howard - chris@kitard.com  (Based on PubSubClient 1.9.1)
 *  D. Guz                           20/01/15  Fix, cleanup, testing
 *  D. Haensse                       26/07/15  Major rewrite, upgrate to MQTT 3.1.1 cleanup www.swissembedded.com
 ********************************************************************/
#define __MQTT_C

#include "TCPIPConfig.h"


#if defined(STACK_USE_MQTT_CLIENT)

#include "TCPIP.h"

#include "generictypedefs.h"

/****************************************************************************
  Section:
        MQTT Client Configuration Parameters
 ***************************************************************************/
#define MQTT_PORT					1883					// Default port to use when unspecified
#define MQTT_PORT_SECURE	8883					// Default port to use when unspecified
#define MQTT_SERVER_REPLY_TIMEOUT	(TICK_SECOND*8)		// How long to wait before assuming the connection has been dropped (default 8 seconds)


/****************************************************************************
  Section:
        MQTT Client Public Variables
 ***************************************************************************/
// The global set of MQTT_POINTERS.
// Set these parameters after calling MQTTBeginUsage successfully.
MQTT_POINTERS MQTTClient;

/****************************************************************************
  Section:
        MQTT Client Internal Variables
 ***************************************************************************/
static IP_ADDR MQTTServer; // IP address of the remote MQTT server
static TCP_SOCKET MySocket = INVALID_SOCKET; // Socket currently in use by the MQTT client

WORD MQTTResponseCode;

BYTE MQTTBuffer[MQTT_MAX_PACKET_SIZE];


/* Message state machine for the MQTT Client, see MQTT-v3.1.1 as reference */
static enum {
    MQTT_HOME = 0,          // MQTT not in use (MQTTEndUsage called or Stack startup)
    MQTT_CONNECT_READY,     // Initialized with MQTTBeginUsage
    MQTT_BEGIN,             // Preparing to make connection
    MQTT_NAME_RESOLVE,      // Resolving the MQTT server address
    MQTT_OBTAIN_SOCKET,     // Obtaining a socket for the MQTT connection
    MQTT_SOCKET_OBTAINED,   // MQTT connection successful
    MQTT_CONNECT,           // MQTT connection
    MQTT_CONNECT_ACK,       // MQTT connected

    MQTT_PUBLISHC,          // MQTT Publish (Client initiates sequence)
    MQTT_PUB_ACKC,          // MQTT PublishAck (if QOS)
    MQTT_PUB_RECC,          // MQTT PublishAck (if QOS)
    MQTT_PUB_RELC,          // MQTT PublishAck (if QOS)
    MQTT_PUB_COMPC,         // MQTT PublishAck (if QOS)
    MQTT_PUBLISHS,          // MQTT Publish (Server initiates sequence)
    MQTT_PUB_ACKS,          // MQTT PublishAck (if QOS)
    MQTT_PUB_RECS,          // MQTT PublishAck (if QOS)
    MQTT_PUB_RELS,          // MQTT PublishAck (if QOS)
    MQTT_PUB_COMPS,         // MQTT PublishAck (if QOS)

    MQTT_SUBSCRIBE,         // MQTT Subscribe
    MQTT_SUBSCRIBE_ACK,     // MQTT SubscribeAck (if QOS)    

    MQTT_UNSUBSCRIBE,       // MQTT Unsubscribe
    MQTT_UNSUBSCRIBE_ACK,   // MQTT UnsubscribeAck (if QOS)

    MQTT_PING,              // MQTT Ping
    MQTT_PING_ACK,          // MQTT Pingback
                
    MQTT_DISCONNECT,        // MQTT Disconnect accepted, and...

    MQTT_CLOSE,             // MQTT connection closed
    MQTT_QUIT,              // MQTT quit
    
    MQTT_IDLE,               // MQTT idle
    MQTT_NORETRIES           // MQTT retries      
} MQTTState, MQTTOldState,MQTTRetriesState;

// Internal flags used by the MQTT Client
static union {
    BYTE Val;

    struct {
        unsigned char MQTTInUse : 1;
        unsigned char ConnectedOnce : 1;
    } bits;
} MQTTFlags = {0x00};


/****************************************************************************
  Section:
        MQTT Client Internal Function Prototypes
 ***************************************************************************/


/****************************************************************************
  Section:
        MQTT Function Implementations
 ***************************************************************************/

/*****************************************************************************
  Function:
        BOOL MQTTBeginUsage(void)

  Summary:
        Requests control of the MQTT client module.

  Description:
        Call this function before calling any other MQTT Client APIs.  This
        function obtains a lock on the MQTT Client, which can only be used by
        one stack application at a time.  Once the application is finished
        with the MQTT client, it must call MQTTEndUsage to release control
        of the module to any other waiting applications.
	
        This function initializes all the MQTT state machines and variables
        back to their default state. Overwrite MQTTClient struct with your settings AFTER
        calling this function.

  Precondition:
        None

  Parameters:
        None

  Return Values:
        TRUE - The application has successfully obtained control of the module
        FALSE - The MQTT module is in use by another application.  Call
                MQTTBeginUsage again later, after returning to the main program loop
 ***************************************************************************/
BOOL MQTTBeginUsage(void) {

    if (MQTTFlags.bits.MQTTInUse)
        return FALSE;

    MQTTFlags.Val = 0x00;
    MQTTFlags.bits.MQTTInUse = TRUE;
    MQTTState = MQTT_CONNECT_READY;
    memset((void*) &MQTTClient, 0x00, sizeof (MQTTClient));
    MQTTClient.Ver = MQTTPROTOCOLVERSION;
    MQTTClient.KeepAlive = (MQTT_KEEPALIVE_LONG);
    MQTTClient.MsgId = 1;
    MQTTClient.ServerPort=0;
    MQTTClient.m_Callback=NULL;
    return TRUE;
}

/*****************************************************************************
  Function:
        WORD MQTTEndUsage(void)

  Summary:
        Releases control of the MQTT client module.

  Description:
        Call this function to release control of the MQTT client module once
        an application is finished using it.  This function releases the lock
        obtained by MQTTBeginUsage, and frees the MQTT client to be used by
        another application. Make sure to cleanup allocated memory after calling this function.
        MQTTClient might be overwritten by call of MQTTBeginUsage at any time.

  Precondition:
        MQTTBeginUsage returned TRUE on a previous call.

  Parameters:
        None

  Return Values:
        MQTT_SUCCESS - A message was successfully sent
        MQTT_CONNECT_ERROR - The connection to the MQTT server failed or was prematurely terminated
 ***************************************************************************/
WORD MQTTEndUsage(void) {

    if (!MQTTFlags.bits.MQTTInUse)
        return 0xFFFF;

    // Release the MQTT module
    MQTTFlags.bits.MQTTInUse = FALSE;
    MQTTState = MQTT_HOME;

    
    // Release the DNS module, if in use
    if (MQTTState == MQTT_NAME_RESOLVE)
        DNSEndUsage();

    // Just close connection, user had change to call disconnect
    if (MQTTClient.bConnected)    
        MQTTStop();   

    // Release the TCP socket, if in use
    if (MySocket != INVALID_SOCKET) {
        TCPDisconnect(MySocket);
        MySocket = INVALID_SOCKET;
        return MQTT_SUCCESS;
    }
    else
    {
        return MQTT_CONNECT_ERROR;
    }
}

BOOL MQTTIsInUse()
{
 return(MQTTFlags.bits.MQTTInUse);
}

/*****************************************************************************
  Function:
        void MQTTStop()

  Summary:
        Force disconnection from server

  Description:

  Precondition:
        MQTTBeginUsage returned TRUE on a previous call.

  Parameters:
        None

  Returns:
        TRUE if MQTTDISCONNECT was send to server
 ***************************************************************************/
BOOL MQTTStop(void) {
    if (MySocket == INVALID_SOCKET)
        return FALSE;
    
    if(TCPIsConnected(MySocket))
    {
     if (TCPIsPutReady(MySocket) >= 2) {
         TCPPut(MySocket,MQTTDISCONNECT);
         TCPPut(MySocket,0);
         TCPFlush(MySocket);
         return 1;
     }
    }
    return FALSE;
}

/*****************************************************************************
  Function:
        void MQTTTask(void)

  Summary:
        Performs any pending MQTT client tasks

  Description:
        This function handles periodic tasks associated with the MQTT client,
        such as processing initial connections and command sequences.

  Precondition:
        None

  Parameters:
        None

  Returns:
        None

  Remarks:
        This function acts as a task (similar to one in an RTOS).  It
        performs its task in a co-operative manner, and the main application
        must call this function repeatedly to ensure that all open or new
        connections are served in a timely fashion.
 ***************************************************************************/
void MQTTTask(void) {
    BYTE cpt,cps;
    static DWORD lastInActivity;
    static DWORD pos=MQTTINIT;    
    

    switch (MQTTState) {
        case MQTT_HOME:
            // MQTTBeginUsage() is the only function which will kick
            // the state machine into the next state
            break;
        case MQTT_CONNECT_READY:
            // Ready for connection wait for MQTTConnect call
            break;

        case MQTT_BEGIN:
            // Open connection to mqtt server
            // Obtain ownership of the DNS resolution module
            if (!DNSBeginUsage())
                break;

            // Obtain the IP address associated with the MQTT server
            if (MQTTClient.Server.szRAM) {
#if defined(__18CXX)
                if (MQTTClient.ROMPointers.Server)
                    DNSResolveROM(MQTTClient.Server.szROM, DNS_TYPE_A);
                else
#endif
                    DNSResolve(MQTTClient.Server.szRAM, DNS_TYPE_A);
            } else {
                MQTTResponseCode = MQTT_RESOLVE_ERROR;
                MQTTState = MQTT_CONNECT_READY; // can't do anything
                break;
            }

            lastInActivity = TickGet();
            MQTTState++;
            break;

        case MQTT_NAME_RESOLVE:
            // Try to resolve MQTT server IP
            // Wait for the DNS server to return the requested IP address
            if (!DNSIsResolved(&MQTTServer)) {
                // Timeout after 6 seconds of unsuccessful DNS resolution
                if ((TickGet() - lastInActivity) > (6 * TICK_SECOND)) {
                    MQTTResponseCode = MQTT_RESOLVE_ERROR;
                    MQTTState = MQTT_CONNECT_READY;
                    DNSEndUsage();
                }
                break;
            }

            // Release the DNS module, we no longer need it, timeout reached
            if (!DNSEndUsage()) {
                // An invalid IP address was returned from the DNS
                // server.  Quit and fail permanantly if host is not valid.
                MQTTResponseCode = MQTT_RESOLVE_ERROR;
                MQTTState = MQTT_CONNECT_READY;
                break;
            }

            MQTTState++;
            // No break; fall into MQTT_OBTAIN_SOCKET

        case MQTT_OBTAIN_SOCKET:
            // Connect a TCP socket to the remote MQTT server
            MySocket = TCPOpen(MQTTServer.Val, TCP_OPEN_IP_ADDRESS, MQTTClient.ServerPort, TCP_PURPOSE_MQTT_SERVER);

            // Abort operation if no TCP sockets are available
            // If this ever happens, make sure 
            // TCP_PURPOSE_MQTT_SERVER sockets are available in TCPIPConfig.h
            if (MySocket == INVALID_SOCKET)
            {
                MQTTResponseCode = MQTT_CONNECT_ERROR;
                MQTTState = MQTT_CONNECT_READY;
                break;
            }
                
            MQTTState++;
            lastInActivity = TickGet();
            // No break; fall into MQTT_SOCKET_OBTAINED


        case MQTT_SOCKET_OBTAINED:
            if (!TCPIsConnected(MySocket)) {
                // Don't stick around in the wrong state if the
                // server was connected, but then disconnected us.
                // Also time out if we can't establish the connection to the MQTT server
                if (MQTTFlags.bits.ConnectedOnce || ((LONG) (TickGet() - lastInActivity) > (LONG) (MQTT_SERVER_REPLY_TIMEOUT))) {
                    MQTTResponseCode = MQTT_CONNECT_ERROR;
                    MQTTState = MQTT_CLOSE;                    
                }
                break;
            }
            MQTTFlags.bits.ConnectedOnce = TRUE;            
            MQTTState++;
            // No break; fall into MQTT_CONNECT

        case MQTT_CONNECT:
        case MQTT_PUBLISHC:
        case MQTT_PUB_RELC:
        case MQTT_PUB_ACKS:
        case MQTT_PUB_RECS:
        case MQTT_PUB_COMPS:
        case MQTT_SUBSCRIBE:
        case MQTT_UNSUBSCRIBE:
        case MQTT_PING:
            if ((MySocket != INVALID_SOCKET) && TCPIsConnected(MySocket)) {
                /* ConnectedOnce indicates connection has just started */
                if (MQTTFlags.bits.ConnectedOnce) {
                    if(MQTTState==MQTT_CONNECT)
                    {
                        pos=MQTTWritePacket(MQTTCONNECT,pos);
                        if(pos==MQTTDONE) MQTTState++; 
                    }
                    else if(MQTTState==MQTT_PUBLISHC)
                    {
                        pos=MQTTWritePacket(MQTTPUBLISH,pos);                        
                        if(pos==MQTTDONE)
                        {
                         if(MQTTClient.HdrFlags.bits.QoS==0)
                            MQTTState=MQTT_IDLE;
                         else if(MQTTClient.HdrFlags.bits.QoS==1)
                            MQTTState=MQTT_PUB_ACKC;
                         else if(MQTTClient.HdrFlags.bits.QoS==2)
                            MQTTState=MQTT_PUB_RECC;                        
                        }
                    }
                    else if(MQTTState==MQTT_PUB_RELC)
                    {
                        pos=MQTTWritePacket(MQTTPUBREL,pos);
                        if(pos==MQTTDONE) MQTTState++;
                    }
                    else if(MQTTState==MQTT_PUB_ACKS)
                    {
                        pos=MQTTWritePacket(MQTTPUBACK,pos);
                        if(pos==MQTTDONE) MQTTState=MQTT_IDLE; 
                    }
                    else if(MQTTState==MQTT_PUB_RECS)
                    {                        
                        pos=MQTTWritePacket(MQTTPUBREC,pos);
                        if(pos==MQTTDONE) MQTTState++;
                    }
                    else if(MQTTState==MQTT_PUB_COMPS)
                    {                        
                        pos=MQTTWritePacket(MQTTPUBCOMP,pos);
                        if(pos==MQTTDONE) MQTTState=MQTT_IDLE; 
                        
                    }
                    else if(MQTTState==MQTT_SUBSCRIBE)
                    {                        
                        pos=MQTTWritePacket(MQTTSUBSCRIBE,pos);
                        if(pos==MQTTDONE) MQTTState++;
                    }
                    else if(MQTTState==MQTT_UNSUBSCRIBE)
                    {                        
                        pos=MQTTWritePacket(MQTTUNSUBSCRIBE,pos);
                        if(pos==MQTTDONE) MQTTState++; 
                    }
                    else if(MQTTState==MQTT_PING)
                    {
                        pos=MQTTWritePacket(MQTTPINGREQ,pos);
                        if(pos==MQTTDONE) MQTTState++; 
                    }
                    else
                    {
                        /* State machine is broken somehow */
                        MQTTStop();
                        MQTTState = MQTT_CLOSE;
                        break;
                    }
                    if(pos==MQTTDONE)
                    {                                          
                     MQTTResponseCode = MQTT_SUCCESS;                     
                     lastInActivity = TickGet();
                     break;
                    }
                    if(pos!=MQTTERROR)
                    {
                        /* we have to wait until transmisstion has finished */
                    }
                    else
                    {
                        MQTTStop();
                        MQTTState = MQTT_CLOSE;
                        break;
                    }
                }
            }          
            else
            {
                /* Connection closed from server */
                MQTTStop();
                MQTTState = MQTT_CLOSE;
                break;
            }
            break;

        case MQTT_CONNECT_ACK:
        case MQTT_PUB_ACKC:
        case MQTT_PUB_RECC:
        case MQTT_PUB_COMPC:
        case MQTT_PUBLISHS:
        case MQTT_PUB_RELS:
        case MQTT_SUBSCRIBE_ACK:
        case MQTT_UNSUBSCRIBE_ACK:     
        case MQTT_PING_ACK:
            if ((MySocket == INVALID_SOCKET))
            {
                MQTTStop();
                MQTTState = MQTT_CLOSE;
                break;
            }
            if(!TCPIsConnected(MySocket))
            {
                MQTTStop();
                MQTTState = MQTT_CLOSE;
                break;                
            }
            /* Wait for response, if not ready iterate */            
            pos = MQTTReadPacket(pos);
            if(pos==MQTTERROR)
            {
                MQTTStop();
                MQTTState=MQTT_CLOSE;
                break;                
            }
            else {                
                if ((TickGet() - lastInActivity) > (TICK_SECOND * 10)) {
                    if((MQTTRetriesState!=MQTT_NORETRIES) && (MQTTClient.Retries>0))
                    {
                        MQTTState=MQTTRetriesState;
                        lastInActivity=TickGet();
                        break;
                    }
                    else                        
                    {
                     MQTTStop();
                     MQTTState=MQTT_CLOSE;                    
                     break;                
                    }
                }                
            }            

            /* Finally parse the packet if all data is available */
            if((pos==MQTTTRANSFER) || (MQTTState==MQTT_CLOSE)) break;    
            lastInActivity = TickGet();
            cpt=MQTTBuffer[0]&MQTTMTMASK;
            if (cpt==MQTTCONNACK) 
            {
                /* Return code */
                switch (MQTTClient.ConnRet) { 
                    case 0:
                        lastInActivity = TickGet();                        
                        MQTTClient.bConnected = TRUE;
                        MQTTState = MQTT_IDLE; //go to idle now                        
                        break;
                    case 1: // unacceptable protocol version
                        MQTTClient.bConnected = FALSE;
                        MQTTResponseCode = MQTT_BAD_PROTOCOL;
                        MQTTState=MQTT_CLOSE;
                        MQTTStop();                                               
                        break;
                    case 2: // identifier rejected
                        MQTTClient.bConnected = FALSE; 
                        MQTTResponseCode = MQTT_IDENT_REJECTED;
                        MQTTState=MQTT_CLOSE;
                        MQTTStop();                                               
                        break;
                    case 3: // server unavailable
                        MQTTClient.bConnected = FALSE; 
                        MQTTResponseCode = MQTT_SERVER_UNAVAILABLE;
                        MQTTState=MQTT_CLOSE;
                        MQTTStop();                                               
                        break;
                    case 4: // bad user o password
                        MQTTClient.bConnected = FALSE; 
                        MQTTResponseCode = MQTT_BAD_USER_PASW;
                        MQTTState=MQTT_CLOSE;
                        MQTTStop();                                               
                        break;
                    case 5: // unauthorized
                        MQTTClient.bConnected = FALSE; 
                        MQTTResponseCode = MQTT_UNAUTHORIZED;
                        MQTTState=MQTT_CLOSE;
                        MQTTStop();                                               
                        break;
                }     
                break;
            }
            else if((cpt==MQTTSUBACK))
            {
                if(MQTTClient.SubAckRet==0x80)
                {
                    MQTTResponseCode = MQTT_OPERATION_FAILED;
                }
                MQTTState = MQTT_IDLE; //go to idle now                
                break;
            }
            else if((cpt==MQTTPUBACK) || (cpt==MQTTPUBCOMP) || (cpt==MQTTUNSUBACK) || (cpt==MQTTPINGRESP))
            {
                MQTTState = MQTT_IDLE; //go to idle now                
                break;
            }
            else if((cpt==MQTTPUBREC)||(cpt==MQTTPUBREL))
            {
                MQTTState++;                
                break;
            }
            else if(cpt==MQTTPUBLISH)
            {                      
                if(MQTTClient.HdrFlags.bits.QoS==0)
                {
                    MQTTState=MQTT_IDLE;    
                }
                else if(MQTTClient.HdrFlags.bits.QoS==1)
                {                    
                    MQTTState=MQTT_PUB_ACKS;                              
                }
                else if(MQTTClient.HdrFlags.bits.QoS==2)
                {
                    MQTTState=MQTT_PUB_RECS;
                }
                else
                {
                    MQTTStop();
                    MQTTState = MQTT_CLOSE;
                }
                if(MQTTClient.m_Callback)
                {
                    MQTTClient.m_Callback(MQTTClient.Topic.szRAM, MQTTClient.Tlength, MQTTClient.Payload.szRAM, MQTTClient.Plength, MQTTClient.HdrFlags.Val);
                }
                break;
            }            
            else
            {
                /* State machine is broken somehow */
                MQTTStop();
                MQTTState = MQTT_CLOSE;
                break;   
            }
            break;


        case MQTT_DISCONNECT:            
            MQTTState = MQTT_CLOSE;
            MQTTStop();            
            break;

        case MQTT_CLOSE:
            // Close the socket so it can be used by other modules
            TCPDisconnect(MySocket);
            MySocket = INVALID_SOCKET;
            MQTTFlags.bits.ConnectedOnce = FALSE;
            MQTTResponseCode=MQTT_FAIL;

            // Go back to doing nothing
            MQTTState = MQTT_QUIT;
            break;

        case MQTT_QUIT:
            if (MySocket != INVALID_SOCKET)
                TCPClose(MySocket);
            MQTTState = MQTT_CONNECT_READY;
            break;
        case MQTT_IDLE:            
            if(MQTTConnected())
            {
                if(TCPIsGetReady(MySocket))
                {
                    cps=cpt=TCPPeek(MySocket, 0);
                    cpt&=MQTTMTMASK;
                    cps&=MQTTFLMASK;                    
                    if(cpt==MQTTPUBLISH)
                    {                       
                       MQTTState=MQTT_PUBLISHS;
                       break;
                    }
                }
                if((TickGet()-lastInActivity) > (MQTTClient.KeepAlive*TICK_SECOND/4))                                        
                {
                    /* Send a ping in 4th of the keep alive time */
                       MQTTState=MQTT_PING;
                       MQTTRetriesState=MQTT_PING;
                       MQTTClient.Retries=3;
                       break;
                }
            }
            else
            {
                /* Not connected anymore somehow */
                MQTTState = MQTT_DISCONNECT;
                break;
            }
            break;

    }
    if(MQTTState!=MQTTOldState)
    {
        pos=MQTTINIT;
        MQTTOldState=MQTTState;
    }
}

/*****************************************************************************
  Function:
        BOOL MQTTIsIdle(void)

  Summary:
        Determines if the MQTT client is IDLE and ready to send new commands.

  Description:
        Call this function to determine if the MQTT client is idle and ready to performing
        background tasks.  This function should be called after any call to
        MQTTPublish, MQTTSubscribe or MQTTUnsubscribe to determine if the stack has finished
        performing its internal tasks.  When this function returns FALSE, the command should be
        recall until the stack is ready again .

  Precondition:
        MQTTBeginUsage returned TRUE on a previous call.

  Parameters:
        None

  Return Values:
        FALSE - The MQTT Client is busy with internal tasks or sending an
                on-the-fly message.
        TRUE - The MQTT Client is ready for new operation.
 ***************************************************************************/
BOOL MQTTIsIdle(void) {

    return ((MQTTState == MQTT_IDLE) || (MQTTState==MQTT_CONNECT_READY));
}

/*****************************************************************************
  Function:
        WORD MQTTPutArray(BYTE* Data, WORD Len)

  Description:
        Writes a series of bytes to the MQTT server.

  Precondition:
        MQTTBeginUsage returned TRUE on a previous call.

  Parameters:
        Data - The data to be written
        Len - How many bytes should be written

  Returns:
        The number of bytes written.  If less than Len, then the TX FIFO became
        full before all bytes could be written.
	
  Remarks:
        This function should only be called internally when the MQTT client is
        generating an on-the-fly message. 

 *  ***************************************************************************/
WORD MQTTPutArray(BYTE* Data, WORD Len) {
    WORD result;

    result = TCPPutArray(MySocket, Data, Len);
    TCPFlush(MySocket);
    return result;
}

/*****************************************************************************
  Function:
        WORD MQTTPutROMArray(ROM BYTE* Data, WORD Len)

  Description:
        Writes a series of bytes from ROM to the MQTT client.

  Precondition:
        MQTTBeginUsage returned TRUE on a previous call.

  Parameters:
        Data - The data to be written
        Len - How many bytes should be written

  Returns:
        The number of bytes written.  If less than Len, then the TX FIFO became
        full before all bytes could be written.
	
  Remarks:
        This function should only be called externally when the MQTT client is
        generating an on-the-fly message.  (That is, MQTTSendMail was called
        with MQTTClient.Body set to NULL.)
	
        This function is aliased to MQTTPutArray on non-PIC18 platforms.
	
  Internal:
        MQTTPut must be used instead of TCPPutArray because "\r\n." must be
        transparently replaced by "\r\n..".
 ***************************************************************************/
#if defined(__18CXX)

WORD MQTTPutROMArray(ROM BYTE* Data, WORD Len) {
    WORD result = 0;

    while (Len--) {
        if (TCPPut(*Data++)) {
            result++;
        } else {
            Data--;
            break;
        }
    }

    return result;
}
#endif

/*****************************************************************************
  Function:
        BOOL MQTTWritePacket(BYTE header, DWORD pos)

  Summary:
        Write MQTT Packet to buffer.

  Description:
        Write MQTT Packet to buffer. The command collects the relevant info from MQTTClient structure

  Precondition:
        MQTTBeginUsage returned TRUE on a previous call.

  Parameters:
        None

  Returns:
        New position in buffer        
 ***************************************************************************/
BOOL MQTTWritePacket(BYTE header, DWORD pos) {    
    BYTE msgtype;
    DWORD remlen, len;
    static DWORD plentx,lentx;

    if (pos == MQTTINIT) {
        pos=0;
        /* This routine can generate the following packets:
         * CONNECT:     Fixed Header 2 bytes and more, variable header 6+1+1+2, payload n bytes 
         * PUBLISH:     Fixed header 2 bytes  and more, variable header 2+n+2, payload n bytes
         * PUBACK:      Fixed header 2 bytes  and more, variable header 2, payload none
         * PUBREC:      Fixed header 2 bytes  and more, variable header 2, payload none
         * PUBREL:      Fixed header 2 bytes  and more, variable header 2, payload none
         * PUBCOMP:     Fixed header 2 bytes  and more, variable header 2, payload none
         * SUBSCRIBE:   Fixed Header 2 bytes and more, variable header 2, payload n bytes 
         * UNSUBSCRIBE: Fixed Header 2 bytes and more, variable header 2, payload none
         * PINGREQ:     Fixed Header 2 bytes, variable header none, payload none
         * DISCONNECT:  Fixed Header 2 bytes, variable header none, payload none
         */

        /* Header with MQTT Control type and remaining length, which is unknown yet */
        /* calculate length and set some flags */
        msgtype = header&MQTTMTMASK;
        switch (msgtype) {
            case MQTTCONNECT:
                /* Fixed header */
                MQTTBuffer[pos++] = header&MQTTMTMASK;
                /* calculate remaining length */
                remlen = 6 + 1 + 1 + 2;

                if (MQTTClient.ClientId.szRAM) 
                {   
                    remlen += 2 + strlen(MQTTClient.ClientId.szRAM);
                }
                if (MQTTClient.ConnFlags.bits.WillFlag) {
                    remlen += 2 + strlen(MQTTClient.WillTopic.szRAM);
                    remlen += 2 + strlen(MQTTClient.WillMessage.szRAM);
                }
                if (MQTTClient.ConnFlags.bits.UserNameFlag) {
                    remlen += 2 + strlen(MQTTClient.Username.szRAM);
                }
                if (MQTTClient.ConnFlags.bits.PasswordFlag) {
                    remlen += 2 + MQTTClient.PassLength;
                }
                if (remlen > (MQTT_MAX_PACKET_SIZE - 5)) return (MQTTERROR);
                /* fill in remaining length */
                pos = MQTTWriteRemainingLength(MQTTBuffer, pos, remlen);
                /* variable header */
                MQTTBuffer[pos++] = 0x00;
                MQTTBuffer[pos++] = 0x04;
                MQTTBuffer[pos++] = 'M';
                MQTTBuffer[pos++] = 'Q';
                MQTTBuffer[pos++] = 'T';
                MQTTBuffer[pos++] = 'T';
                /* Protocol Level */
                MQTTBuffer[pos++] = MQTTPROTOCOLVERSION;
                /* Connect Flags */
                MQTTBuffer[pos++] = MQTTClient.ConnFlags.Val;
                /* Keep Alive */
                MQTTBuffer[pos++] = HIBYTE(MQTTClient.KeepAlive);
                MQTTBuffer[pos++] = LOBYTE(MQTTClient.KeepAlive);                
                /* Client Identifier */
                pos = MQTTWriteString(MQTTClient.ClientId.szRAM, MQTTBuffer, pos);
                /* Will Topic & Will Message */
                if (MQTTClient.ConnFlags.bits.WillFlag) {
                    pos = MQTTWriteString(MQTTClient.WillTopic.szRAM, MQTTBuffer, pos);
                    pos = MQTTWriteString(MQTTClient.WillMessage.szRAM, MQTTBuffer, pos);
                }
                /* Username */
                if (MQTTClient.ConnFlags.bits.UserNameFlag) {
                    pos = MQTTWriteString(MQTTClient.Username.szRAM, MQTTBuffer, pos);
                }

                /* Password, binary format must be allowed */
                if (MQTTClient.ConnFlags.bits.PasswordFlag) {
                    pos = MQTTWriteArray(MQTTClient.Password.szRAM, MQTTClient.PassLength, MQTTBuffer, pos);
                }                
                break;
            case MQTTPUBLISH:                 
                /* Fixed header */
                MQTTBuffer[pos++] = ((header&MQTTMTMASK) | (MQTTClient.HdrFlags.Val&MQTTFLMASK));
                if(MQTTClient.HdrFlags.bits.QoS>0) MQTTClient.PktId++;
                  
                /* calculate remaining length */
                remlen = 0;                                
                if (MQTTClient.Topic.szRAM) remlen += 2+strlen(MQTTClient.Topic.szRAM);
                if(MQTTClient.HdrFlags.bits.QoS>0) remlen += 2; /* only present Qos>0 */
                if(MQTTClient.Payload.szRAM) remlen +=MQTTClient.Plength;              
                if (remlen > (MQTT_MAX_PACKET_SIZE - 5)) return (MQTTERROR);
                /* fill in remaining length */
                pos = MQTTWriteRemainingLength(MQTTBuffer, pos, remlen);
                /* variable header */
                if(MQTTClient.Topic.szRAM)
                {
                 pos = MQTTWriteString(MQTTClient.Topic.szRAM, MQTTBuffer, pos);
                }
                /* Paket identifier */
                if(MQTTClient.HdrFlags.bits.QoS>0)
                {
                 MQTTBuffer[pos++] = HIBYTE(MQTTClient.PktId);
                 MQTTBuffer[pos++] = LOBYTE(MQTTClient.PktId);                
                }
                /* Payload */
                if(MQTTClient.Payload.szRAM)
                {
                 memcpy(&MQTTBuffer[pos],MQTTClient.Payload.szRAM,MQTTClient.Plength);
                 pos+=MQTTClient.Plength;
                }                
                break;
            case MQTTPUBACK:
            case MQTTPUBREC:
            case MQTTPUBREL:
            case MQTTPUBCOMP:                   
                /* Fixed header */
                MQTTBuffer[pos++] = ((header&MQTTMTMASK) | (msgtype==MQTTPUBREL ? 0x02 : 00));                

                /* calculate remaining length */
                remlen = 2;                
                /* fill in remaining length */
                pos = MQTTWriteRemainingLength(MQTTBuffer, pos, remlen);
                /* variable header */                
                /* Paket identifier */
                MQTTBuffer[pos++] = HIBYTE(MQTTClient.PktId);
                MQTTBuffer[pos++] = LOBYTE(MQTTClient.PktId);                               
                break;
            case MQTTSUBSCRIBE:                
                /* Fixed header */
                MQTTBuffer[pos++] = (header&MQTTMTMASK)|0x02;
                MQTTClient.PktId++;

                /* calculate remaining length */
                remlen = 2;
                if (MQTTClient.Topic.szRAM) remlen += 2+1+strlen(MQTTClient.Topic.szRAM);
                if (remlen > (MQTT_MAX_PACKET_SIZE - 5)) return (MQTTERROR);
                /* fill in remaining length */
                pos = MQTTWriteRemainingLength(MQTTBuffer, pos, remlen);
                /* variable header */
                /* Paket identifier */
                MQTTBuffer[pos++] = HIBYTE(MQTTClient.PktId);
                MQTTBuffer[pos++] = LOBYTE(MQTTClient.PktId);                               
                /* payload */
                /* Topic filter FIXME only one filter at a time possible */
                if(MQTTClient.Topic.szRAM)
                {
                 pos = MQTTWriteString(MQTTClient.Topic.szRAM, MQTTBuffer, pos);
                 /* QOS */
                 MQTTBuffer[pos++]=MQTTClient.QOS;
                }
                break;
            case MQTTUNSUBSCRIBE:
                /* Fixed header */
                MQTTBuffer[pos++] = (header&MQTTMTMASK)|0x02;
                MQTTClient.PktId++;

                /* calculate remaining length */
                remlen = 2;
                if (MQTTClient.Topic.szRAM) remlen += 2+strlen(MQTTClient.Topic.szRAM);
                if (remlen > (MQTT_MAX_PACKET_SIZE - 5)) return (MQTTERROR);
                /* fill in remaining length */
                pos = MQTTWriteRemainingLength(MQTTBuffer, pos, remlen);
                /* variable header */
                /* Paket identifier */
                MQTTBuffer[pos++] = HIBYTE(MQTTClient.PktId);
                MQTTBuffer[pos++] = LOBYTE(MQTTClient.PktId);                               
                /* payload */
                /* Topic filter FIXME only one filter at a time possible */
                if(MQTTClient.Topic.szRAM)
                {
                    pos = MQTTWriteString(MQTTClient.Topic.szRAM, MQTTBuffer, pos);
                }
                break;
            case MQTTPINGREQ:
            case MQTTDISCONNECT:                
                /* Fixed header */
                MQTTBuffer[pos++] = (header&MQTTMTMASK);                
                /* calculate remaining length */
                remlen = 0;
                /* fill in remaining length */
                pos = MQTTWriteRemainingLength(MQTTBuffer, pos, remlen);
                break;
        }
        plentx = pos;
        lentx=pos;
    }
    if(plentx>0)
    {
        len=TCPIsPutReady(MySocket);
        if(len > plentx) len=plentx;
        len=MQTTPutArray(&MQTTBuffer[lentx-plentx],len);
        TCPFlush(MySocket);
        plentx-=len;
    }
    return(plentx);
       
}

/*****************************************************************************
  Function:
        DWORD MQTTWriteRemainingLength(BYTE *buf,DWORD pos, DWORD remainlength)

  Summary:
        Calculate and write remaining length data to buffer.

  Description:
        Calculate and write remaining length data to buffer. The remaining length encoding is up to 4 bytes.

  Precondition:
        MQTTBeginUsage returned TRUE on a previous call.

  Parameters:
        None

  Returns:
        New position in buffer        
 ***************************************************************************/
DWORD MQTTWriteRemainingLength(BYTE *buf,DWORD pos, DWORD remainlength)
{
    BYTE digit;    
    DWORD len=remainlength;
    do {
        digit = len & 0x7f;
        len = len >> 7;
        if (len > 0) {
            digit |= 0x80;
        }
        buf[pos++] = digit;        
    } while (len > 0);
    return(pos);
}

/*****************************************************************************
  Function:
        WORD MQTTWriteString(const char *string, BYTE *buf, WORD pos)

  Summary:
        Write string data to MQTT buffer.

  Description:
        Write string data to MQTT buffer including lengt field (WORD).

  Precondition:
        MQTTBeginUsage returned TRUE on a previous call.

  Parameters:
        None

  Returns:
        New position in buffer        
 ***************************************************************************/
WORD MQTTWriteString(const char *string, BYTE *buf, WORD pos) {
    const char *idp = string;
    WORD i = 0;

    pos += 2;
    /* Fill in the string */
    if(string!=NULL)
    {     
     while (*idp) {
        buf[pos++] = *idp++;
        i++;
     }
    }
    /* Fill in the length */
    buf[pos - i - 2] = HIBYTE(i);
    buf[pos - i - 1] = LOBYTE(i);
    return pos;
}

/*****************************************************************************
  Function:
        MQTTWriteArray(const BYTE *string, WORD len, BYTE *buf, WORD pos)

  Summary:
        Write binary data to MQTT buffer.

  Description:
        Write binary data to MQTT buffer including lengt field (WORD).

  Precondition:
        MQTTBeginUsage returned TRUE on a previous call.

  Parameters:
        None

  Returns:
        New position in buffer        
 ***************************************************************************/
WORD MQTTWriteArray(const BYTE *string, WORD len, BYTE *buf, WORD pos) {
    const char *idp = string;
    WORD i = 0;

    pos += 2;
    /* Fill in the string */
    if(string!=NULL)
    {     
     for(i=0;i<len;i++) 
     {
        buf[pos++] = *idp++;        
     }
    }
    /* Fill in the length */
    buf[pos - i - 2] = HIBYTE(i);
    buf[pos - i - 1] = LOBYTE(i);
    return pos;
}

#if defined(__18CXX)

WORD MQTTWriteROMString(const ROMchar *string, BYTE *buf, WORD pos) {
    const char *idp = string;
    WORD i = 0;

    pos += 2;
    while (*idp) {
        buf[pos++] = *idp++;
        i++;
    }
    buf[pos - i - 2] = HIBYTE(i);
    buf[pos - i - 1] = LOBYTE(i);
    return pos;
}
#endif

/*****************************************************************************
  Function:
        BOOL MQTTConnected(void) {

  Summary:
        Check if connected to mqtt server

  Description:
        This function checkes the state of the connection to the mqtt server

  Precondition:
        MQTTBeginUsage returned TRUE on a previous call.

  Parameters:
        None

  Returns:
        True  Connected to server
        False Disconnected from server
 ***************************************************************************/
BOOL MQTTConnected(void) {
    if (MySocket == INVALID_SOCKET) {        
        MQTTClient.bConnected=FALSE;        
    }
    else if (!TCPIsConnected(MySocket)) {
        MQTTClient.bConnected=FALSE;
    }
    return(MQTTClient.bConnected);    
}

inline BYTE MQTTReadByte(void) { 
    BYTE ch;

    TCPGet(MySocket, &ch);
    return ch;
}

/*****************************************************************************
  Function:
        WORD MQTTReadPacket(DWORD pos)

  Summary:
        Read part or full MQTT response from server

  Description:
        This function can be called iteratively until an timeout occured

  Precondition:
        TCPIsConnected must be called prior to this function call

  Parameters:
        Current position in input buffer

  Returns:
        DWORD new position in input buffer
 ***************************************************************************/
DWORD MQTTReadPacket(DWORD epos) {        
    BYTE digit = 0;
    static BYTE m_state;
    static BYTE msgtype,status;
    static DWORD remlen, multiplier, remlenrec,vpos,cpos,pos;

    /* reset state machine on first byte */
    if(epos==MQTTINIT) {m_state = 0; pos=0;}
    
    /* Read a packet 
     * Fixed header, wih message type (1 byte) and remaining length (1-4 bytes)
     * Variable header
     * Payload
     */
    switch (m_state) {
        case 0: /* We need at least two bytes from fixed header to start parsing */            
            if (TCPIsGetReady(MySocket) >= 2) 
            {
                MQTTBuffer[pos++] = MQTTReadByte();
                msgtype=MQTTBuffer[0]&MQTTMTMASK; 
                status=MQTTBuffer[0]&MQTTFLMASK; 
                MQTTClient.Retained=status&1;
                MQTTClient.QOS=(status>>1)&3;
                MQTTClient.DUP=(status>>3)&1;
                remlen=0;
                remlenrec=0;
                multiplier=1;
                m_state++;
            }
            else
                break;
        case 1: /* remaining length up to 4 bytes */
            while(TCPIsGetReady(MySocket) && (m_state==1))
            {
                MQTTBuffer[pos++] = digit = MQTTReadByte();
                remlen += ((digit & 0x7f) * multiplier);
                multiplier <<= 7;
                if((digit & 0x80) == 0) 
                {
                   m_state++;                   
                   vpos=pos;
                   /* Sanity check of packet lenght, if too long, reject it */
                   if(remlen > (MQTT_MAX_PACKET_SIZE-pos))
                       return(MQTTERROR);    
                   if(remlen==0) 
                   {
                       remlenrec=remlen;
                       /* Skip receive variable header and payload */
                       m_state++;
                   }
                }                
                if(pos==5) /* error remaining length max 4 bytes ! */
                    return(MQTTERROR);                
            }
            if(m_state!=3)
                break;
            // continue processing
        case 2:
            /* Just receive the number of bytes as indicated in remaining length bytes */
            while(TCPIsGetReady(MySocket))
            {
                MQTTBuffer[pos++] = MQTTReadByte();
                remlenrec++;
                if(remlenrec==remlen)
                {
                   m_state++;
                   break;
                }                
            }
            if(m_state!=3)
                break;
            // continue processing

        case 3:
            /* Finally parse the message, extracting the for the stack relevant infos 
             * the following packets are processed and they have the following characteristic:
             * CONNACK:  variable header 2 bytes, payload none
             * PUBLISH:  variable header topic name (2 or more bytes), identifier (2bytes), payload (0 or more bytes)
             * PUBACK:   variable header 2 bytes, payload none
             * PUBREC:   variable header 2 bytes, payload none
             * PUBREL:   variable header 2 bytes, payload none
             * PUBCOMP:  variable header 2 bytes, payload none
             * SUBACK:   variable header 2 bytes, payload 1 byte
             * UNSUBACK: variable header 2 bytes, payload none
             * PINGRESP: variable header none, payload none
             */
            switch(msgtype)
            {
                case MQTTCONNACK:
                    MQTTClient.ConnAck=MQTTBuffer[vpos]&0x1;
                    MQTTClient.ConnRet=MQTTBuffer[vpos+1];
                    break;
                case MQTTSUBACK:
                    MQTTClient.SubAckRet=MQTTBuffer[vpos+2];
                    /* finally message id, see below */
                case MQTTPUBACK:
                case MQTTPUBREC:
                case MQTTPUBREL:
                case MQTTPUBCOMP:                
                case MQTTUNSUBACK:                                    
                    MQTTClient.MsgId=(MQTTBuffer[vpos]<<8)|MQTTBuffer[vpos+1];                    
                    break;
                case MQTTPUBLISH:                 
                    MQTTClient.HdrFlags.Val=status;
                    MQTTClient.Tlength=(MQTTBuffer[vpos]<<8)|MQTTBuffer[vpos+1];                    
                    if(MQTTClient.Tlength > 0)
                        MQTTClient.Topic.szRAM=&MQTTBuffer[vpos+2];
                    else
                        MQTTClient.Topic.szRAM=NULL;                    
                    cpos=vpos+MQTTClient.Tlength+2;
                    if(MQTTClient.HdrFlags.bits.QoS>0)
                    {
                        MQTTClient.PktId=(MQTTBuffer[cpos]<<8)|MQTTBuffer[cpos+1];
                        cpos+=2;
                    }
                    MQTTClient.Plength=remlen-(cpos-vpos);
                    if(MQTTClient.Plength > 0)
                        MQTTClient.Payload.szRAM=&MQTTBuffer[cpos];
                    else
                        MQTTClient.Payload.szRAM=NULL;
                    break;
                case MQTTPINGRESP:
                    /* no content */
                    break;
                default:
                    /* unknown packet */
                    return(MQTTERROR);
            }
            m_state++;
            break;
        default:
            break;
    }
    /* return the length when we have have parsed the packet */
    if((remlenrec==remlen) && (m_state==4) )
    {
        return(remlen);
    }
    else return(MQTTTRANSFER);
}


/*****************************************************************************
  Function:
        BOOL MQTTConnect(BYTE conflags, const char *id, const char *user, const BYTE *pass, WORD passlen, const char *willTopic, const char *willMessage)

  Summary:
        Connects to a server with given ID etc.

  Description:
        Connect to the server. Use the conflags from header file to set the correct MQTT flags to the server, depending on these flags, 
 *      the parameter from function call are send to the server.

  Precondition:
        MQTTBeginUsage returned TRUE on a previous call.

  Parameters:
        None

  Returns:
        True  State machine was in the condition to start initialisation of the connection
        False State machine was busy with other things and connect was be called again after stack iteration
 ***************************************************************************/
BOOL MQTTConnect(BYTE conflags, const char *id, const char *user, const BYTE *pass, WORD passlen, const char *willTopic, const char *willMessage) {

    if (MQTTState == MQTT_CONNECT_READY) {        
        if(MQTTClient.ServerPort==0)
        {
            MQTTClient.ServerPort = MQTTClient.bSecure ? MQTT_PORT_SECURE : MQTT_PORT;
        }

        MQTTClient.ClientId.szRAM = id;
        MQTTClient.Username.szRAM = user;
        MQTTClient.Password.szRAM = pass;
        MQTTClient.PassLength=passlen;
        MQTTClient.WillTopic.szRAM = willTopic;
        MQTTClient.WillMessage.szRAM = willMessage;
        MQTTClient.ConnFlags.Val=conflags;        
        MQTTState = MQTT_BEGIN;
        MQTTRetriesState=MQTT_NORETRIES;
        return 1;
    }
    return 0;
}

/*****************************************************************************
  Function:
        void MQTTPing(void)

  Summary:
        Sends a PING message

  Description:
        Send a PING message to the MQTT server and wait for the response.

  Precondition:
        MQTTBeginUsage returned TRUE on a previous call.

  Parameters:
        None

  Returns:
        None
 ***************************************************************************/
BOOL MQTTPing(void) {

    if (MQTTState == MQTT_IDLE) {
        if (MQTTClient.bConnected) {
            MQTTState = MQTT_PING;
            MQTTClient.Retries=0;                       
            MQTTRetriesState=MQTT_NORETRIES;
            return 1;
        }
    }
    return 0;
}

/*****************************************************************************
  Function:
        BOOL MQTTPublish(BYTE const hdrflags, char *topic, const BYTE *payload, WORD plength)

  Summary:
        Publishes data for a topic

  Description:
        Publish data item.

  Precondition:
        MQTTBeginUsage returned TRUE on a previous call.

  Parameters:
        None

  Returns:
        None
 ***************************************************************************/
BOOL MQTTPublish(BYTE const hdrflags, char *topic, const BYTE *payload, WORD plength) {

    //solo per ROM ovvero per C30!
    if (MQTTState == MQTT_IDLE) {
        if (MQTTClient.bConnected) {
            MQTTClient.Topic.szRAM = topic;
            MQTTClient.Payload.szRAM = payload;
            MQTTClient.Plength = plength;
            MQTTClient.HdrFlags.Val = hdrflags;
            if(MQTTClient.HdrFlags.bits.QoS >0 ) MQTTClient.Retries=3;
            else MQTTClient.Retries=0;

            MQTTRetriesState= MQTTState = MQTT_PUBLISHC;
            return 1;
        }
    }
    return 0;
}

 


/*****************************************************************************
  Function:
        void MQTTUnsubscribe(const char topic, BYTE qos)

  Summary:
        Subscribes to a topic

  Description:
        Subscribe to a MQTT message. 

  Precondition:
        MQTTBeginUsage returned TRUE on a previous call.

  Parameters:
        None

  Returns:
        TRUE Message was successfully send
        FALSE State machine is busy, try later again
 ***************************************************************************/
BOOL MQTTSubscribe(const char *topic, BYTE qos) {

    //solo per ROM ovvero per C30!
    if (MQTTState == MQTT_IDLE) {
        if (MQTTClient.bConnected) {
            MQTTClient.Topic.szRAM = topic;
            MQTTClient.QOS = qos;
            if(qos >0 ) MQTTClient.Retries=3;
            else MQTTClient.Retries=0;
            MQTTRetriesState= MQTTState = MQTT_SUBSCRIBE;
            return 1;
        }
    }
    return 0;
}

/*****************************************************************************
  Function:
        void MQTTUnsubscribe(const char topic)

  Summary:
        Unsubscribes to a topic

  Description:
        Unsubscribe from a MQTT message. 

  Precondition:
        MQTTBeginUsage returned TRUE on a previous call.

  Parameters:
        None

  Returns:
        TRUE Message was successfully send
        FALSE State machine is busy, try later again
 ***************************************************************************/
BOOL MQTTUnsubscribe(const char *topic) {

    //solo per ROM ovvero per C30!
    if (MQTTState == MQTT_IDLE) {
        if (MQTTClient.bConnected) {
            MQTTClient.Topic.szRAM = topic;            
            MQTTClient.Retries=0;
            
            MQTTRetriesState= MQTTState = MQTT_UNSUBSCRIBE;
            
            return 1;
        }
    }
    return 0;
}

/*****************************************************************************
  Function:
        void MQTTDisconnect()

  Summary:
        Disconnects gracefully (already done in Close anyway)

  Description:

  Precondition:
        MQTTBeginUsage returned TRUE on a previous call.

  Parameters:
        None

  Returns:
        None
 ***************************************************************************/
BOOL MQTTDisconnect(void) {

    if (MQTTState == MQTT_IDLE) {
        if (MQTTClient.bConnected) {
            MQTTState = MQTT_DISCONNECT;
            return 1;
        }
    }
    return 0;
}





#endif //#if defined(STACK_USE_MQTT_CLIENT)

