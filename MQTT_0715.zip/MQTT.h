/*********************************************************************
 *
 *                  MQTT (Internet of Things Protocol) Client
 *									Module for Microchip TCP/IP Stack
 *
 *********************************************************************
 * FileName:        mqtt.h
 * Dependencies:    TCP.h
 * Processor:       PIC18, PIC24F, PIC24H, dsPIC30F, dsPIC33F, PIC32
 * Compiler:        Microchip C32 v1.05 or higher
 *					Microchip C30 v3.12 or higher
 *					Microchip C18 v3.30 or higher
 *					HI-TECH PICC-18 PRO 9.63PL2 or higher
 * Company:         Microchip Technology, Inc.
 *
 * Software License Agreement
 *
 * Copyright (C) 2002-2009 Microchip Technology Inc.  All rights reserved.
 * Copyright (C) 2013,2014 Cyberdyne.  All rights reserved.
 *
 * Microchip licenses to you the right to use, modify, copy, and
 * distribute:
 * (i)  the Software when embedded on a Microchip microcontroller or
 *      digital signal controller product ("Device") which is
 *      integrated into Licensee's product; or
 * (ii) ONLY the Software driver source files ENC28J60.c, ENC28J60.h,
 *		ENCX24J600.c and ENCX24J600.h ported to a non-Microchip device
 *		used in conjunction with a Microchip ethernet controller for
 *		the sole purpose of interfacing with the ethernet controller.
 *
 * You should refer to the license agreement accompanying this
 * Software for additional information regarding your rights and
 * obligations.
 *
 *
 * Author               Date    Comment
 *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 * Howard Schlunder     3/03/06	Original
 * Dario Greggio				30/9/14	mqtt client start
 * D. Guz                           20/01/15  Fix, cleanup, testing
 * D. Haensse                       26/07/15  Major rewrite, upgrate to MQTT 3.1.1 cleanup www.swissembedded.com
 ********************************************************************/
#ifndef __MQTT_H
#define __MQTT_H

/****************************************************************************
  Section:
	Data Type Definitions
  ***************************************************************************/
	#define MQTT_SUCCESS		(0x0000u)	// successfully 
	#define MQTT_FAIL				(0xffffu)	// error 
	#define MQTT_RESOLVE_ERROR	(0x8000u)	// DNS lookup for MQTT server failed
	#define MQTT_CONNECT_ERROR	(0x8001u)	// Connection to MQTT server failed
	#define MQTT_BAD_PROTOCOL		(0x8101u)	// connect: bad protocol
	#define MQTT_IDENT_REJECTED	(0x8102u)	// connect: id rejected
	#define MQTT_SERVER_UNAVAILABLE	(0x8103u)	// connect: server unavailable
	#define MQTT_BAD_USER_PASW		(0x8104u)	// connect: bad user or password
	#define MQTT_UNAUTHORIZED			(0x8105u)	// connect: unauthorized
	#define MQTT_OPERATION_FAILED	(0x8201u)	// publish, subscribe error

// MQTT_MAX_PACKET_SIZE : Maximum packet size
#define MQTT_MAX_PACKET_SIZE 256

// MQTT_KEEPALIVE : keepAlive interval in Seconds
#define MQTT_KEEPALIVE_REALTIME 4
#define MQTT_KEEPALIVE_SHORT 15
#define MQTT_KEEPALIVE_LONG 120

#define MQTTPROTOCOLVERSION 4
#define MQTTCONNECT     (1 << 4)  // Client request to connect to Server
#define MQTTCONNACK     (2 << 4)  // Connect Acknowledgment
#define MQTTPUBLISH     (3 << 4)  // Publish message
#define MQTTPUBACK      (4 << 4)  // Publish Acknowledgment
#define MQTTPUBREC      (5 << 4)  // Publish Received (assured delivery part 1)
#define MQTTPUBREL      (6 << 4)  // Publish Release (assured delivery part 2)
#define MQTTPUBCOMP     (7 << 4)  // Publish Complete (assured delivery part 3)
#define MQTTSUBSCRIBE   (8 << 4)  // Client Subscribe request
#define MQTTSUBACK      (9 << 4)  // Subscribe Acknowledgment
#define MQTTUNSUBSCRIBE (10 << 4) // Client Unsubscribe request
#define MQTTUNSUBACK    (11 << 4) // Unsubscribe Acknowledgment
#define MQTTPINGREQ     (12 << 4) // PING Request
#define MQTTPINGRESP    (13 << 4) // PING Response
#define MQTTDISCONNECT  (14 << 4) // Client is Disconnecting
#define MQTTReserved    (15 << 4) // Reserved
#define MQTTMTMASK 0xf0 // Message Type Mask (Fixed header)
#define MQTTFLMASK 0x0f // Flags (Fixed header)
#define MQTTINIT     0xffffffffl // Init statemachine
#define MQTTERROR    0xfffffffel // Error statemachine
#define MQTTTRANSFER 0xfffffffdl // Transfer statemachine
#define MQTTDONE     0x0l // Transfer statemachine

#define MQTTQOS0        (0 << 1)
#define MQTTQOS1        (1 << 1)
#define MQTTQOS2        (2 << 1)

/* Connect */
#define MQTTCONCLEANSESSION (1<<1)
#define MQTTCONWILLFLAG     (1<<2)
#define MQTTCONWILLQOS0     (0<<3)
#define MQTTCONWILLQOS1     (1<<3)
#define MQTTCONWILLQOS2     (2<<3)
#define MQTTCONWILLRETAIN   (1<<5)
#define MQTTCONPASSWORDFLAG (1<<6)
#define MQTTCONUSERFLAG     (1<<7)

/* Publish */
#define MQTTPUBRETAIN       (1<<0)
#define MQTTPUBQOSLEVEL0    (0<<1)	
#define MQTTPUBQOSLEVEL1    (1<<1)	
#define MQTTPUBQOSLEVEL2    (2<<1)	
#define MQTTPUBDUP          (3<<1)

/* Subscribe */
#define MQTTSUBQOSLEVEL0    0	
#define MQTTSUBQOSLEVEL1    1	
#define MQTTSUBQOSLEVEL2    2	

/****************************************************************************
  Function:
      typedef struct MQTT_POINTERS
    
  Summary:
    Configures the MQTT client to send a message
    
  Description:
    This structure of pointers configures the MQTT Client to send an e-mail
    message. Initially, all pointers will be null.
    
        
  Parameters:
    Server -        the MQTT server to receive the message(s)
    User		 -      the user name to use when logging into the POP3 server,
                    if any is required
    Pass		 -      the password to supply when logging in, if any is required
    bSecure -       Port (method) to use
    ServerPort -    (WORD value) Indicates the port on which to connect to the
                    remote MQTT server.

  Remarks:

  ***************************************************************************/


typedef struct {
    /* MQTT Connect specific stuff */
	union {
		char *szRAM;
		} Server;
	union	{
		char *szRAM;
		} Username;
	union	{
		BYTE *szRAM;
		} Password;
        WORD PassLength;
	union	{
		char *szRAM;
		} ClientId;
    union	{
		char *szRAM;
		} WillTopic;
	union	{
		char *szRAM;
		} WillMessage;

    union {
        BYTE Val;
        struct {
            unsigned char Reserved : 1;
            unsigned char CleanSession : 1;
            unsigned char WillFlag : 1;
            unsigned char WillQoS : 2;
            unsigned char WillRetain : 1;
            unsigned char PasswordFlag : 1;
            unsigned char UserNameFlag : 1;
        } bits;
    }  ConnFlags;
    BYTE ConnAck;
    BYTE ConnRet;

    /* MQTT Publish */
    union {
        BYTE Val;
        struct {
            unsigned char RETAIN : 1;
            unsigned char QoS : 2;            
            unsigned char DUP : 1;
            unsigned char ControlPacketType : 4;                        
        } bits;
    }  HdrFlags;
	void (*m_Callback)(const char *topic, WORD tlength, const BYTE *payload, WORD plength, BYTE conflag);

    
	union	{
		char *szRAM;
		} Topic;
	union	{
		BYTE *szRAM;
		} Payload;

	WORD Plength;	
    WORD Tlength;
	BYTE Ver;
	WORD ServerPort;
	WORD MsgId;
    WORD PktId;
	WORD KeepAlive;    
	BYTE QOS;
    BYTE DUP;
    BYTE Retained;
	BYTE bSecure;
	BYTE bConnected;
	BYTE bAvailable;
	FILE *Stream;
    int Retries;
    BYTE SubAckRet;
    
    
	
	} MQTT_POINTERS;


/****************************************************************************
  Section:
	Global MQTT Variables
  ***************************************************************************/
extern MQTT_POINTERS MQTTClient;
extern BYTE MQTTBuffer[MQTT_MAX_PACKET_SIZE];
extern WORD MQTTResponseCode;
	
/****************************************************************************
  Section:
	MQTT Function Prototypes
  ***************************************************************************/

BOOL MQTTBeginUsage(void);
WORD MQTTEndUsage(void);
BOOL MQTTIsInUse();
void MQTTTask(void);
BOOL MQTTConnect(BYTE conflags, const char *id, const char *user, const BYTE *pass, WORD passlen, const char *willTopic, const char *willMessage);
BOOL MQTTPublish(BYTE const hdrflags, char *topic, const BYTE *payload, WORD plength);
BOOL MQTTIsIdle(void);
BOOL MQTTSubscribe(const char *topic, BYTE qos);
BOOL MQTTUnsubscribe(const char *topic);
BOOL MQTTPing(void);
BOOL MQTTDisconnect(void);
BOOL MQTTStop(void);

/* Copy the data, immediately when callback is called, strings are not 0 terminated use strncpy or memcpy */
void MQTTCallback(const char *topic, WORD tlength, const BYTE *payload, WORD plength, BYTE conflag);

WORD MQTTWriteString(const char *, BYTE *, WORD );
WORD MQTTWriteArray(const BYTE *string, WORD len, BYTE *buf, WORD pos);
BOOL MQTTWritePacket(BYTE header, DWORD pos);
DWORD MQTTWriteRemainingLength(BYTE *buf,DWORD pos, DWORD remainlength);
DWORD MQTTReadPacket(DWORD pos);
BOOL MQTTPut(BYTE c);
WORD MQTTPutArray(BYTE* Data, WORD Len);
BYTE MQTTReadByte(void);
BOOL MQTTConnected(void);


#if defined(__18CXX)
	WORD MQTTPutROMArray(ROM BYTE* Data, WORD Len);
	WORD MQTTPutROMString(ROM BYTE* Data);
	WORD MQTTPutROMString(ROM BYTE *Data);
	WORD MQTTPutROMArray(ROM BYTE *Data, WORD Len);
	WORD MQTTWriteROMString(const ROM char *, BYTE *, WORD );
#else
	// Non-ROM variant for C30 / C32
	#define MQTTPutROMArray(a,b)	MQTTPutArray((BYTE *)a,b)
	// Non-ROM variant for C30 / C32
	#define MQTTPutROMString(a)		MQTTPutString((BYTE *)a)
	#define MQTTWriteROMString(String, Data, Len) MQTTWriteROMString(String, Data, Len)
#endif




#endif
